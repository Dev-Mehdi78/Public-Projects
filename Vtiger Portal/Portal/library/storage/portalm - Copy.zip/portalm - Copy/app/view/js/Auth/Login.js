
let SettingFetch=await import ("../Fetch/Setting.js?v="+Date.now())
let CommonFetch=await import ("../Fetch/Common.js?v="+Date.now())
const FetchingLogin=CommonFetch.FetchingLogin

const URLPATH=SettingFetch.URLPATH

const LoginBtn=document.getElementById("LoginBtn");
let Username=document.getElementById("username")
let Password=document.getElementById("password")

if(LoginBtn!==null){
    LoginBtn.onclick=()=>{
        FetchingLogin(Username.value,Password.value,(response)=>{
            if(response.success===true){
                
                window.location.href=URLPATH+'TiketList'
            }else{
                alert(response.error.message);
            }
        });
    }
  
}