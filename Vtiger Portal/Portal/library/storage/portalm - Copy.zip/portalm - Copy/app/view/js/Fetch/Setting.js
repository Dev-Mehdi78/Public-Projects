// export const URLAPI='http://demopackage4.a-web.ir/vttest/modules/ParsVT/ws/Portal/';
export const URLAPI='http://192.168.100.252/CRMNEW/modules/ParsVT/ws/Portal/';

//export const URLPATH='http://localhost/protalm/';
export const URLPATH='http://192.168.100.252/portalm/';

