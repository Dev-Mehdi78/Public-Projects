import { URLAPI } from "./Setting.js";


export const FetchingLogin = (username, password,fn) => {
    const myHeaders = new Headers();
    myHeaders.set('Authorization', 'Basic ' + btoa(username + ":" + password));
    const requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow'
    };

    fetch(URLAPI + "?operation=Ping", requestOptions)
        .then(response => response.json())
        .then(json => fn(json));

}