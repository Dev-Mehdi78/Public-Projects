<?php

class tiketList
{
    private $Main;
    function __construct()
    {
        $this->Main=new Main;
        $this->Main->SetTitle("TiketList");
        $Css='';
        $Js='';
        $this->Main->SetJs($Js);
        $this->Main->SetCss($Css);
        $this->Main->SetHeaders("layout/Header.phtml");

       $this->Main->CreateViewHeaderFooterSideMenu("TiketList.phtml");
       
    }
}
