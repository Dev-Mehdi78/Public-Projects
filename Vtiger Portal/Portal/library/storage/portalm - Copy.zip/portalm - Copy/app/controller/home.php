<?php

class Home
{
    private $Main, $Curls;

    function __construct()
    {
        
    }
}
