<?php
define("CONTROLLER_PATH","app/controller/");
define("URL_API","http://192.168.100.252/CRMNEW/modules/ParsVT/ws/Portal/");
define("URL_Domain","http://192.168.100.252/portalm/");
define("VIEW_PATH",URL_Domain."app/view/");
define("VIEW_PATH_INCLUDE","app/view/");
define("VERSION",rand(0,150000));


?>