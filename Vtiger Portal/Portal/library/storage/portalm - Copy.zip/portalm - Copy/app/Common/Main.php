<?php

class Main
{
    private $bootstrap_css,
        $bootstrap_js,
        $jquery,
        $jsFile,
        $CssFile,
        $meta,
        $js,
        $Css,
        $Footer,
        $Header,

        $title,
        $favIco,
        $Curls;
    function __construct()
    {
        $this->Curls = new Curls;


        $this->favIco = '';

        $this->meta = '  <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">';
    }
    public function SetThemDefault()
    {
        $this->bootstrap_css = '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" 
        integrity="sha384-tKLJeE1ALTUwtXlaGjJYM3sejfssWdAaWR2s97axw4xkiAdMzQjtOjgcyw0Y50KU" crossorigin="anonymous">';

        $this->jquery = '
        <script src="' . VIEW_PATH . 'asset/js/jquery-3.3.1.min.js"></script>
     
        ';

        $this->bootstrap_js = '    
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" 
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
         crossorigin="anonymous"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>';


        $this->jsFile = '
        <script src="' . VIEW_PATH . 'asset/js/plugins-jquery.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/chart-init.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/calendar.init.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/sparkline.init.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/morris.init.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/datepicker.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/sweetalert2.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/toastr.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/validation.js?v=' . VERSION . '"></script>
        <script src="' . VIEW_PATH . 'asset/js/lobilist.js?v=' . VERSION . '"></script>
        ';

        $this->CssFile = '<link rel="stylesheet" href="' . VIEW_PATH . 'asset/css/style.css?v=' . VERSION . '">
        ';
    }



    public function SetTitle($title)
    {
        $this->title = "<title>" . $title . "</title>";
    }

    public function SetCss($css)
    {
        $this->Css = $css;
    }

    public function SetHeaders($headers)
    {
        $this->Header = $headers;
    }

    public function SetFooter($footer)
    {
        $this->Footer = $footer;
    }

    public function SetJs($js)
    {
        $this->js = $js;
    }

    private function CreateHeader()
    {
        $header = '<!DOCTYPE html><html lang="en" dir="rtl"><head>';
        $header .= $this->meta;
        $header .= $this->favIco;
        $header .= $this->bootstrap_css;
        $header .= $this->CssFile;
        $header .= $this->Css;

        $header .= $this->title;
        $header .= '</head>';
        echo $header;
    }


    private function CreateScriptJs()
    {
        $script = '';
        $script .= $this->jquery;
        $script .= $this->bootstrap_js;
        $script .= $this->jsFile;
        $script .= $this->js;

        echo $script;
    }

    public function CreateView($view, $data = [])
    {
        $this->SetThemDefault();
        $URL_Domain = URL_Domain;
        $URL_API = URL_API;
        $VIEW_PATH = VIEW_PATH;
        $VIEW_PATH_INCLUDE = VIEW_PATH_INCLUDE;
        $data = $data;
        $this->CreateHeader();
        include(VIEW_PATH_INCLUDE . $view);
        $this->CreateScriptJs();
    }

    public function CreateViewHeaderFooterSideMenu($view, $auth = true, $datas = [])
    {
        $this->SetThemDefault();
        $URL_Domain = URL_Domain;
        $URL_API = URL_API;
        $VIEW_PATH = VIEW_PATH;
        $VIEW_PATH_INCLUDE = VIEW_PATH_INCLUDE;
        $data = $datas;


        $this->CreateHeader();


        include(VIEW_PATH_INCLUDE . $this->Header);

        include(VIEW_PATH_INCLUDE . $view);

        include(VIEW_PATH_INCLUDE . $this->Footer);
        $this->CreateScriptJs();
    }

    public function CreateViewHeaderFooter($view, $datas = [])
    {

        $this->SetThemDefault();
        $URL_Domain = URL_Domain;
        $URL_API = URL_API;
        $VIEW_PATH = VIEW_PATH;
        $VIEW_PATH_INCLUDE = VIEW_PATH_INCLUDE;
        $data = $datas;



        $this->CreateHeader();
        include(VIEW_PATH_INCLUDE . $this->Header);
        echo '<div class="main-page">';
        include(VIEW_PATH_INCLUDE . $view);
        echo '</div>';
        include(VIEW_PATH_INCLUDE . $this->Footer);
        $this->CreateScriptJs();
    }
}
